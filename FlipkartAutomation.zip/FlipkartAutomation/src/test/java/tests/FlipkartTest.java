package tests;

import base.BaseTest;
import pages.FlipkartPage;
import utils.ExcelUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.*;
import java.util.*;

public class FlipkartTest extends BaseTest {
    FlipkartPage fp;

    @BeforeClass
    public void setup() {
        initialization();
        fp = new FlipkartPage();
    }

    @Test
    public void validateAndSaveExcel() throws InterruptedException {
        String searchKey = ExcelUtils.getReadData(1, 0); 
        fp.performSearch(searchKey);
        fp.applyFilters();

        // Sync: Wait for the product list to appear
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("RG5Slk")));

        // Scrape Names and Prices
        List<WebElement> names = driver.findElements(By.className("RG5Slk"));
        List<WebElement> prices = driver.findElements(By.xpath("//div[@class='hZ3P6w DeU9vF']"));

        List<String> finalNames = new ArrayList<>();
        List<String> finalPrices = new ArrayList<>();

        int count = Math.min(names.size(), 5);
        System.out.println("Found " + names.size() + " products. Saving Top " + count);

        for (int i = 0; i < count; i++) {
            finalNames.add(names.get(i).getText());
            finalPrices.add(prices.get(i).getText());
        }

        // --- THE EXCEL SAVE STEP ---
        ExcelUtils.writeToExcel(finalNames, finalPrices);

        // Validation Checkpoint
        int firstPrice = Integer.parseInt(finalPrices.get(0).replaceAll("[^0-9]", ""));
        Assert.assertTrue(firstPrice < 30000, "Price validation failed!");
    }

    @AfterClass
    public void tearDown() { if (driver != null) driver.quit(); }
}