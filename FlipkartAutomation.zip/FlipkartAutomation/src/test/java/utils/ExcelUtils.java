package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.*;
import java.util.List;

public class ExcelUtils {
    // Reads keyword from testdata.xlsx
    public static String getReadData(int row, int col) {
        try (FileInputStream fis = new FileInputStream("./src/test/resources/testdata.xlsx")) {
            Workbook wb = WorkbookFactory.create(fis);
            return wb.getSheetAt(0).getRow(row).getCell(col).toString();
        } catch (Exception e) { return "mobiles"; }
    }

    // Writes Top 5 to OutputResults.xlsx
    public static void writeToExcel(List<String> names, List<String> prices) {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet s = wb.createSheet("Top 5 Results");
            Row header = s.createRow(0);
            header.createCell(0).setCellValue("Mobile Name");
            header.createCell(1).setCellValue("Price");

            for (int i = 0; i < names.size(); i++) {
                Row r = s.createRow(i + 1);
                r.createCell(0).setCellValue(names.get(i));
                r.createCell(1).setCellValue(prices.get(i));
            }

            try (FileOutputStream fos = new FileOutputStream("./src/test/resources/OutputResults.xlsx")) {
                wb.write(fos);
                System.out.println("Excel saved successfully in resources folder!");
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}