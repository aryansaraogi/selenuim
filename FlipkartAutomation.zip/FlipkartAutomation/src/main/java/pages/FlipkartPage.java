package pages;

import base.BaseTest;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

public class FlipkartPage extends BaseTest {
    By searchBox = By.name("q");
    By maxPriceDropdown = By.xpath("//div[@class='WoGl7t']//select");
    By osSection = By.xpath("//div[contains(text(),'Operating System')]");
    By pieCheckbox = By.xpath("//div[@title='Android Pie']//div//div");
    By sortBtn = By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div[1]/div/div/div[2]/div[5]");

    public void performSearch(String keyword) {
        WebElement sb = wait.until(ExpectedConditions.visibilityOfElementLocated(searchBox));
        sb.sendKeys(keyword);
        String searchOption = "mobiles under 15000";
        WebElement auto = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//li//div[contains(translate(., 'M', 'm'), '" + searchOption + "')]")
        ));
        auto.click();
    }

    public void applyFilters() throws InterruptedException {
        WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(maxPriceDropdown));
        new Select(dropdown).selectByValue("10000");
        Thread.sleep(2000);

        try {
            wait.until(ExpectedConditions.elementToBeClickable(osSection)).click();
            wait.until(ExpectedConditions.elementToBeClickable(pieCheckbox)).click();
            Thread.sleep(2000);
        } catch (Exception e) { System.out.println("Pie Filter skipped."); }

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollTo(0, 0);");
        Thread.sleep(4000);
        wait.until(ExpectedConditions.elementToBeClickable(sortBtn)).click();
        Thread.sleep(3000); // Wait for sort to finish
    }
}