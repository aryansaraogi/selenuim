package pages;

import base.BaseTest;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

public class SearchPage extends BaseTest {
    By searchBox = By.name("q");
    By priceDropdown = By.xpath("(//select)[2]");
    By osSection = By.xpath("//div[text()='Operating System']");
    By pieFilter = By.xpath("//div[@title='Android Pie']");

    public void search(String text) {
        WebElement s = wait.until(ExpectedConditions.visibilityOfElementLocated(searchBox));
        s.sendKeys(text);
        // Using a more generic 'under' suggestion locator
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(.,'15000')]"))).click();
    }

    public void applyFilters() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            // Price Filter
            WebElement d = wait.until(ExpectedConditions.presenceOfElementLocated(priceDropdown));
            new Select(d).selectByValue("10000");
            Thread.sleep(2000);

            // OS Section - Wrapped in a local try-catch so it doesn't kill the whole test
            try {
                WebElement os = wait.until(ExpectedConditions.presenceOfElementLocated(osSection));
                js.executeScript("arguments[0].click();", os);
                WebElement pie = wait.until(ExpectedConditions.elementToBeClickable(pieFilter));
                js.executeScript("arguments[0].click();", pie);
            } catch (Exception e) {
                System.out.println("Warning: 'Android Pie' filter not found. Continuing...");
            }

            // Newest First
            WebElement sort = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='Newest First']")));
            js.executeScript("arguments[0].click();", sort);
            Thread.sleep(3000);
        } catch (Exception e) {
            System.out.println("Filter Step encountered an issue: " + e.getMessage());
        }
    }
}