package FlipkartAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Scanner;

public class FlipkartAutomation {

    public static WebDriver driver;
    public static WebDriverWait wait;

    public static void main(String[] args) {
        
        // 1. User Input for Browser Selection
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter browser name (Chrome/Firefox): ");
        String browserChoice = scanner.nextLine();
        
        try {
            // Launch Browser
            initializeBrowser(browserChoice);
            
            // 2. Open Website
            driver.get("https://www.flipkart.com/");
            driver.manage().window().maximize();
            System.out.println("Website Launched.");

            // 3. Handle Popups (Login Popup)
           // handlePopup();

            // 4. Search and Auto-Suggest
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("q")));
            searchBox.sendKeys("mobiles");
            
            // Wait for auto-suggest to appear and click "mobiles under 15000"
            // Note: We use XPath to find the text specifically within the suggestion list
            String searchOption = "mobiles under 15000";
            WebElement autoSuggest = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//li//div[contains(translate(., 'M', 'm'), '" + searchOption + "')]")
            ));
            autoSuggest.click();
            System.out.println("Selected search option: " + searchOption);

            // 5. Handle Dropdown: Filter Price Max 10000
            // Flipkart uses a <select> dropdown for Min/Max prices in the sidebar
            WebElement maxPriceDropdown = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//div[@class='WoGl7t']//select") // Locates the 'Max' dropdown
            ));
            Select selectPrice = new Select(maxPriceDropdown);
            selectPrice.selectByValue("10000");
            System.out.println("Price filter applied: Max 10000");
            
            // Wait for results to refresh after filtering
            Thread.sleep(2000); 

            // 6. Filter OS: "Pie"
            // Note: 'Pie' is an older Android version. If not found, we catch the exception to prevent crash.
            try {
                // Expand 'Operating System' section if it exists (Flipkart often collapses filters)
                WebElement osSection = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//div[contains(text(),'Operating System')]")));
                osSection.click();
                
                WebElement pieCheckbox = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//div[@title='Android Pie']//div//div")));
                pieCheckbox.click();
                System.out.println("OS Filter 'Pie' applied.");
                Thread.sleep(2000);
            } catch (Exception e) {
                System.out.println("Warning: OS Filter 'Android Pie' not found on current page. Proceeding without it.");
            }

            // 7. Sort: Newest First
            try {
            	JavascriptExecutor jse=(JavascriptExecutor) driver;
            	jse.executeScript("window.scrollTo(0, 0);");
            	Thread.sleep(5000);
                WebElement sortButton = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div[1]/div/div/div[2]/div[5]")));
                sortButton.click();
                System.out.println("Sorted by 'Newest First'.");
                Thread.sleep(2000);
            } catch (Exception e) {
                System.out.println("Warning: Sort option 'Newest First' not available.");
            }

            // 8. Display First 5 Mobiles & Validation
            List<WebElement> productNames = driver.findElements(By.className("RG5Slk")); // Class for Product Name
            List<WebElement> productPrices = driver.findElements(By.xpath("//div[@class='hZ3P6w DeU9vF']")); // Class for Price

            System.out.println("\n--- Top 5 Mobiles ---");
            int count = Math.min(productNames.size(), 5);
            int firstPriceInt = 0;

            for (int i = 0; i < count; i++) {
                String name = productNames.get(i).getText();
                String priceText = productPrices.get(i).getText();
                
                System.out.println((i + 1) + ". " + name + " | Price: " + priceText);

                // Checkpoint Logic for the first item
                if (i == 0) {
                    // Remove symbols (₹) and commas to parse integer
                    String cleanPrice = priceText.replaceAll("[^0-9]", "");
                    firstPriceInt = Integer.parseInt(cleanPrice);
                }
            }

            // 9. Validation Checkpoint
            System.out.println("\n--- Validation Checkpoint ---");
            if (firstPriceInt < 30000) {
                System.out.println("PASS: The first mobile price (" + firstPriceInt + ") is less than 30,000.");
            } else {
                System.out.println("FAIL: The first mobile price (" + firstPriceInt + ") is NOT less than 30,000.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 10. Close Browser
            if (driver != null) {
                driver.quit();
                System.out.println("Browser closed.");
            }
            scanner.close();
        }
    }

    // Method to initialize browser
    public static void initializeBrowser(String browserName) {
        if (browserName.equalsIgnoreCase("Chrome")) {
            // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver"); // Uncomment if not in PATH
            driver = new ChromeDriver();
        } else if (browserName.equalsIgnoreCase("Firefox")) {
            // System.setProperty("webdriver.gecko.driver", "path/to/geckodriver"); // Uncomment if not in PATH
            driver = new FirefoxDriver();
        } else {
            throw new IllegalArgumentException("Browser not supported. Please enter Chrome or Firefox.");
        }
        
        // Define Explicit Wait (15 Seconds)
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    // Method to handle dynamic login popup
    public static void handlePopup() {
        try {
            // Check for the "X" button on the login modal
            WebElement closeButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//button[contains(text(),'✕')]")
            ));
            closeButton.click();
            System.out.println("Popup handled.");
        } catch (Exception e) {
            System.out.println("No popup appeared.");
        }
    }
}